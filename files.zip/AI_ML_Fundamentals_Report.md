# AI & Machine Learning Fundamentals — Concept Report

---

## 1. What is Artificial Intelligence?

Artificial Intelligence (AI) refers to the simulation of human intelligence in machines that are programmed to think, reason, learn, and solve problems. The term was coined by John McCarthy in 1956, when he organised the first AI conference at Dartmouth College.

At its core, AI is about building systems that can:
- **Perceive** their environment (through cameras, microphones, sensors, or text)
- **Reason** over what they perceive
- **Learn** from experience
- **Act** to achieve goals

### AI vs Machine Learning vs Deep Learning

These three terms are often confused but represent a hierarchy:

```
Artificial Intelligence  ← broadest field
  └── Machine Learning   ← AI that learns from data
        └── Deep Learning ← ML using multi-layered neural networks
```

- **AI** is the goal: intelligent behaviour in machines.
- **ML** is the most common method: systems that improve automatically from experience.
- **Deep Learning** is a powerful ML technique inspired by the brain's neural structure.

---

## 2. Types of AI

### Narrow AI (Weak AI)
Narrow AI is designed and trained to perform **one specific task**. It is the only form of AI that exists today.

| Example | Task it performs |
|---------|-----------------|
| Google Translate | Language translation |
| Spotify Discover Weekly | Music recommendation |
| Tesla Autopilot | Lane-keeping and object detection |
| ChatGPT | Text generation and conversation |
| AlphaFold | Protein structure prediction |

Despite the word "narrow", these systems can **far outperform humans** at their specific task — DeepMind's AlphaGo defeated the world Go champion in 2016.

### General AI (Strong AI / AGI)
General AI refers to a machine that possesses the same broad, flexible intellectual capabilities as a human — able to reason across any domain, understand context, and learn new skills without task-specific training.

**AGI does not currently exist.** It remains one of the biggest open problems in science. Research areas working towards it include:
- Meta-learning (learning to learn)
- Multi-modal AI (combining vision, language, and reasoning)
- World models (building internal representations of how the world works)

---

## 3. Types of Machine Learning

### 3.1 Supervised Learning

The model is trained on **labelled data** — pairs of (input, correct output). It learns the mapping from inputs to outputs and can then predict outputs for new, unseen inputs.

**Analogy:** A student studying from a textbook with an answer key.

**Two main tasks:**
- **Classification** — predict a category (spam/not-spam, cat/dog, disease/healthy)
- **Regression** — predict a continuous number (house price, temperature, stock value)

**Common algorithms:** Linear Regression, Logistic Regression, Decision Trees, Random Forests, Support Vector Machines (SVM), Neural Networks

**Real-world examples:**
- Email spam detection
- Medical diagnosis from X-rays
- Credit card fraud detection
- House price prediction

---

### 3.2 Unsupervised Learning

The model is given **unlabelled data** and must discover hidden structure on its own — no correct answers are provided.

**Analogy:** Sorting a pile of foreign coins you've never seen before — you'd naturally group them by size, colour, or markings.

**Main tasks:**
- **Clustering** — group similar data points (K-Means, DBSCAN)
- **Dimensionality Reduction** — compress data while preserving structure (PCA, t-SNE)
- **Anomaly Detection** — find unusual patterns

**Real-world examples:**
- Customer segmentation for targeted marketing
- Topic modelling in news articles
- Detecting unusual network traffic (cybersecurity)
- Compressing images

---

### 3.3 Reinforcement Learning (RL)

An **agent** takes actions in an **environment**, receives **rewards or penalties**, and learns a **policy** — a strategy for choosing actions that maximises cumulative reward over time.

**Analogy:** Training a dog. Give it a treat when it sits, say "no" when it doesn't — over time it learns the desired behaviour.

**Key components:**
| Term | Meaning |
|------|---------|
| Agent | The learner/decision-maker |
| Environment | The world the agent interacts with |
| State | The current situation |
| Action | What the agent can do |
| Reward | Feedback signal (+/-) |
| Policy | Strategy: state → best action |

**Real-world examples:**
- AlphaGo / AlphaZero (board games)
- Robot locomotion and manipulation
- Personalised news feed ordering
- RLHF — training language models to follow human instructions

---

## 4. The Machine Learning Pipeline

Every ML project follows a similar sequence:

```
1. Define the problem
      ↓
2. Collect data
      ↓
3. Explore & preprocess data  (EDA, cleaning, feature engineering)
      ↓
4. Choose a model
      ↓
5. Train the model
      ↓
6. Evaluate the model         (accuracy, F1, AUC, etc.)
      ↓
7. Tune / improve
      ↓
8. Deploy to production
      ↓
9. Monitor & maintain
```

> 💡 In practice, steps 2–7 are highly iterative — you'll cycle through them many times before a model is production-ready.

---

## 5. Real-World Applications of AI/ML

### Healthcare
- **Disease detection:** CNNs analyse chest X-rays to flag pneumonia or cancer with radiologist-level accuracy.
- **Drug discovery:** ML models predict how molecules bind to proteins, dramatically speeding up pharmaceutical research.
- **Clinical NLP:** Models extract structured data from unstructured doctor's notes.

### Finance
- **Fraud detection:** Real-time anomaly detection flags unusual card transactions within milliseconds.
- **Algorithmic trading:** RL agents execute thousands of trades per second based on market signals.
- **Credit scoring:** ML models assess loan risk more accurately than traditional rule-based systems.

### Retail & E-commerce
- **Recommendations:** Collaborative filtering drives 35% of Amazon's revenue.
- **Demand forecasting:** ML predicts which products to stock, reducing waste and stockouts.
- **Dynamic pricing:** Prices adjust in real time based on demand, competition, and inventory.

### Transport
- **Autonomous vehicles:** Combine computer vision, sensor fusion, and RL for self-driving decisions.
- **Route optimisation:** Google Maps uses ML to predict travel times and suggest optimal routes.
- **Predictive maintenance:** Airlines use ML to flag engine components likely to fail before they do.

### Media & Entertainment
- **Content recommendation:** Netflix saves ~$1B/year through personalised recommendations that reduce churn.
- **Speech recognition:** Whisper and similar models transcribe speech across 100+ languages.
- **Content moderation:** ML classifiers detect harmful content at a scale impossible for human reviewers.

### Agriculture
- **Crop disease detection:** Drone imagery + CNN models identify diseased patches of crops early.
- **Yield prediction:** Models trained on weather, soil, and satellite data forecast harvest volumes.
- **Precision irrigation:** IoT sensors + ML decide exactly when and where to water, cutting usage by 30–50%.

---

## 6. Key Concepts to Know

| Concept | Definition |
|---------|-----------|
| **Training data** | Data used to teach the model |
| **Test data** | Held-out data used only for final evaluation |
| **Overfitting** | Model memorises training data, fails on new data |
| **Underfitting** | Model is too simple to capture the pattern |
| **Loss function** | Measures how wrong the model's predictions are |
| **Gradient descent** | Algorithm that minimises the loss by adjusting weights |
| **Hyperparameter** | Setting chosen before training (e.g. learning rate) |
| **Feature** | An individual input variable used by the model |
| **Label** | The correct output the model is trying to predict |

---

## 7. Ethical Considerations

AI systems can cause real harm if not built responsibly:

- **Bias:** Models trained on biased data can perpetuate discrimination (e.g. biased hiring tools).
- **Privacy:** ML models trained on personal data can inadvertently memorise sensitive information.
- **Transparency:** Many powerful models (deep neural networks) are "black boxes" — hard to explain.
- **Job displacement:** Automation may shift employment patterns significantly.
- **Misinformation:** Generative AI can produce convincing false content at scale.

Responsible AI development involves fairness audits, explainability techniques, data governance, and inclusive design practices.

---

*Report completed as part of the AI/ML Internship Program.*
